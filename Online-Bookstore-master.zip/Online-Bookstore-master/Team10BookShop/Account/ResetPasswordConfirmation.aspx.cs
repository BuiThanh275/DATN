﻿using System.Web.UI;

namespace Team10BookShop.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}